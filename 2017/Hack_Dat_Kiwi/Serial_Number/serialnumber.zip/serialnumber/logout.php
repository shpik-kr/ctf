<?php
logout();
header("location: ./");
