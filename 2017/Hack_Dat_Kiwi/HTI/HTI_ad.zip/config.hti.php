<?php
define("ti_mode",3); //1=PTI, 2=NTI, 3=HTI (PTI+NTI)
